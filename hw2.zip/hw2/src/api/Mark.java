package api;

/**
 * Constants for mark value for a <code>Cell</code>.
 */
public enum Mark
{
  NONE, FLAG, QUESTION_MARK
}
